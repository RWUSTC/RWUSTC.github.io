/* Empty file to keep MinGW happy */

int main(void)
{
   return 0;
}

