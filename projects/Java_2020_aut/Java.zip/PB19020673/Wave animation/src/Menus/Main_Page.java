package Menus;


import Interface.Interface;

import Waves_animations.DopplerEffect;
import Waves_animations.SimpleHarmonicMotion;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class Main_Page extends Application implements Interface{

//Create Main Page stage and Main Menu scenes
    private Stage mainPage;
    private Scene[] mainPageScene = new Scene[INDEX_FOUR];
    private Scene[] animationPageScenes = new Scene[INDEX_SIX];
    
//Create class objects
    private Menu_Layouts menuLayouts = new Menu_Layouts();

    private SimpleHarmonicMotion wavesAnimation = new SimpleHarmonicMotion();
    private DopplerEffect dopplerAnimation = new DopplerEffect();

    
//Create Event Handlers    
    private EventHandler<ActionEvent> mainPageButtonAction = new mainPageAction();
    private EventHandler<ActionEvent> staticAction = new staticAction();
    private EventHandler<ActionEvent> animationPageAction = new animationPageAction();
    
//Create Button arrays for each page
    private Button[] mainPageChoices;

    private Button[] wavesChoices;

    
    @Override
    public void start(Stage stage) {
        mainPage = stage;
        setScenes();
        setButtonActions();
        mainPage.setScene(mainPageScene[INDEX_THREE]);
        mainPage.show();
    }

    public void setScenes(){
//Get layouts for the different scenes and set each one in the appropriate array
        for(int i=0; i<mainPageScene.length; i++){
            menuLayouts.setLayout(i);
            mainPageScene[i] = new Scene(menuLayouts.getLayout(i),sceneWidth,sceneHeight);
            mainPageScene[i].getStylesheets().add(Main_Page.class.getResource("Menu_Design.css").toExternalForm());
        }
//Set animation scenes in the array

        animationPageScenes[INDEX_ZERO] = wavesAnimation.getScene();
        animationPageScenes[INDEX_ONE] = dopplerAnimation.getScene();
   
        for(int j=0; j<2; j++){
            animationPageScenes[j].getStylesheets().add(Main_Page.class.getResource("Menu_Design.css").toExternalForm());
        }
    }
    
    public void setButtonActions(){
//Get buttons from the Menu_Layouts class and set them in the appropriate array        
        mainPageChoices = menuLayouts.getButtons(INDEX_ONE);

        wavesChoices = menuLayouts.getButtons(INDEX_ZERO);

        
//Set the Event Handler for each button in the main page
        for(int i=0; i<mainPageChoices.length; i++){
            mainPageChoices[i].setOnAction(mainPageButtonAction);
        }

//Set the Event Handler for each button in the menu pages
        for(int i=0; i<2; i++){
            //Buttons that display an animation page
            if(i<2){
                
                wavesChoices[i].setOnAction(animationPageAction);
             
            //Buttons that returns to the main page
            }else{
               
                wavesChoices[i].setOnAction(staticAction);
                       
            }
        }
    }
    
    class mainPageAction implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){
     
            if(e.getSource().equals(mainPageChoices[INDEX_ZERO]) || e.getSource().equals(wavesAnimation.getReturnButton())
                    || e.getSource().equals(dopplerAnimation.getReturnButton())){
                mainPage.setScene(mainPageScene[INDEX_THREE]);
            }
            
            if(e.getSource().equals(mainPageChoices[INDEX_ONE])){
                System.exit(0);
            }
        }
    }
    
    class staticAction implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){

            if(
                    e.getSource() == wavesChoices[INDEX_TWO] )
            {
                mainPage.setScene(mainPageScene[INDEX_TWO]);
            }
        }
    }
    
    class animationPageAction implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){

            if(e.getSource().equals(wavesChoices[INDEX_ZERO])){
                mainPage.setScene(animationPageScenes[INDEX_ZERO]);
                wavesAnimation.getReturnButton().setOnAction(mainPageButtonAction);
            }
            if(e.getSource().equals(wavesChoices[INDEX_ONE])){
                mainPage.setScene(animationPageScenes[INDEX_ONE]);
                dopplerAnimation.getReturnButton().setOnAction(mainPageButtonAction);
            }
     
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}