
package Menus;

import Interface.Interface;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Menu_Layouts implements Interface{
    
    private Button[] temporaryButtonSet;
    private Text[] title = new Text[2];

    public void setLayout(int pos){
        switch(pos){

            default: 
                labels[INDEX_ZERO] = oscillation; labels[INDEX_ONE] = doppler; 
                 labels[INDEX_TWO] = back;
                temporaryButtonSet = wavesButtonSet; break;
      

        }
        
        for(int i=0; i<2; i++){
            temporaryButtonSet[i].setPrefSize(400, 100);
            temporaryButtonSet[i].setText(labels[i]);
        }
        
        buttonGroup[pos].getChildren().addAll(temporaryButtonSet);
        buttonGroup[pos].setAlignment(Pos.CENTER);

        buttonGroup[pos].setPadding(new Insets(100,0,0,0));
        
        
        

        title[1] = new Text("Hefeng Xu's Homework on JAVA programming");
        
        
            
            mainPages[pos].setPadding(new Insets(300,0,50,0));
            mainPages[pos].setAlignment(title[1], Pos.TOP_CENTER);
            mainPages[pos].setTop(title[1]);
    
        
        mainPages[pos].setCenter(buttonGroup[pos]);
    }
    
    public BorderPane getLayout(int pos){
        return mainPages[pos];
    }
    
    public Button[] getButtons(int pos){
     if(pos == INDEX_ZERO){
            return wavesButtonSet;
        
        }else{
            return mainPageButtonSet;
        }
    }
}